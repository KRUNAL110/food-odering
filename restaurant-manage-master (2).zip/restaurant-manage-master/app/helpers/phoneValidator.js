export function phoneValidator(phone) {
    if (phone.length < 10 || phone.length > 10) return 'Enter in correct Format'
    return ''
}